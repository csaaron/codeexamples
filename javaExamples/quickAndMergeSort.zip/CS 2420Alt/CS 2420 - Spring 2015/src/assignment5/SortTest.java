package assignment5;

import java.util.ArrayList;
import java.util.Comparator;

public class SortTest
{

	public static void main (String[] args)
	{
		ArrayList<Integer> myList = new ArrayList<Integer>();
		Comparator<Integer> compare = new Comparator<Integer>()
		{

			@Override
			public int compare (Integer leftInt, Integer rightInt)
			{
				return leftInt.compareTo(rightInt);
			}

		};

		int timesToLoop = 100;
		for (int i = 0; i < timesToLoop; i++)
		{
			myList.add((int)(Math.random()*timesToLoop));
			
		}
		
		System.out.print("[ ");
		for (Integer i: myList)
		{
			System.out.print(i + " ");
		}
		System.out.print("]");
		System.out.println();
		
		SortUtil.quicksort(myList, compare);
		System.out.print("[ ");
		for (Integer i: myList)
		{
			System.out.print(i + " ");
		}
		System.out.print("]");
	}

}
