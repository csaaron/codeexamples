/**
 * Michael Cline and Aaron Bellis
 * CS 2420
 */
package assignment12;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Random;

public class HuffmanTreeExperiment
{
	public static void main (String[] args)
	{
		final int STRINGSIZE = 100000;
		final int DENOMINATOR = 10;
		HuffmanTreeExperiment timing = new HuffmanTreeExperiment();
		HuffmanTree compressor = new HuffmanTree();

		// get user active directory
		String path = System.getProperty("user.dir");
		path += "\\";


		// Frequency chars
		for (int i = 1; i <= DENOMINATOR; i += 1)
		{
			//int charFrequency = i * 1000;
			String fileName = path + "charFrequency" + i + "in" + DENOMINATOR + ".txt";
			String compressedFileName = path + "charFrequency" + i + "in" + DENOMINATOR + "Compressed.txt";
			try
			{
                timing.generateFile (fileName, STRINGSIZE, i, DENOMINATOR);
			}
			catch (Exception e)
			{
			}
			File uncompressed = new File(fileName);
			File compressed = new File(compressedFileName);
			compressor.compressFile(uncompressed, compressed);
			System.out.println( "Char frequency:  " + i + " in " + DENOMINATOR + "\t||\t" + "Compression Ratio: " + ((double) compressed.length()/uncompressed.length()));
		}
	}

	// X Data Set (tested on a file with 100,000 characters)
	// Number of frequency of characters 10,000 , 20,000 , 30,000 , 40,000 , 50,000
	// Number of unique characters 8, 16, 32, 64
	int count = 0;
	int frequency = 100;
	int currentUniqueChars = 0;
	HashSet<Character> table;

	/**
	 * Generates the test file
	 *
	 * @param filename    -- the desired filename of the test file
	 * @param stringLenth -- the size of the Strings to be generated in the test file
	 * @param ratioNum    - the numerator of the ratio of char 'A' should be ratioNum/ratioDenom
	 * @param ratioDenom  - the denominator of the ratio of char 'A' should be ratioNum/ratioDenom
	 */
	public File generateFile (String filename, int stringLenth, int ratioNum, int ratioDenom)
			throws FileNotFoundException, UnsupportedEncodingException
	{
		File file = new File(filename);
		PrintWriter writer = new PrintWriter(file, "UTF-8");
		writer.print(randomString(stringLenth, ratioNum, ratioDenom));
		writer.close();
		return file;
	}

	/**
	 * Create a random string with characters 'B' - z of specified length with ratioNum /ratioDenom character 'A'
	 *
	 * @param length     - the length of the generated string
	 * @param ratioNum   - the numerator of the ratio of char 'A' should be ratioNum/ratioDenom
	 * @param ratioDenom - the denominator of the ratio of char 'A' should be ratioNum/ratioDenom
	 */
	public String randomString (int length, int ratioNum, int ratioDenom)
	{
		Random rand = new Random();         // Instantiate a random object
		String retval = "";                 // Initialize out String
		int beginingVal = (int) 'B';        // Set our beginning char val past monitored char a

		while (true)     // Loop until we have desired String length
		{
			for (int j = 0; j < ratioDenom; j++)    // For ratio data set
			{
				char currentChar = 'A';     // Set current char
				/*
                 * If our total char value is in the range for he number of random chars to be printed, print random char
                 * Otherwise we will add 'a' to the String
                 */
				if (j < ratioDenom - ratioNum)
				{
					currentChar = (char) (beginingVal + (rand.nextInt(56)));        // Generate a random char
				}
				retval += currentChar; // Add the chars to the return generated String
				if (retval.length() >= length)
				{
					return retval;
				}
			}
		}
	}
}
