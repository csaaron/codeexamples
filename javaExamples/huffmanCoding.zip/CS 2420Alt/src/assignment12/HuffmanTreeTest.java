/**
 * By: Michael Cline and Aaron Bellis
 * CS 2420
 */

package assignment12;

import assignment12.HuffmanTree;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.io.*;
import static org.junit.Assert.*;


public class HuffmanTreeTest
{
	HuffmanTree tester;
	String helloTest;
	String path;

	@Before public void setUp () throws Exception
	{
		tester = new HuffmanTree();
		helloTest = "hello world";

		// get path string will be equal to the root of this project
		path = System.getProperty("user.dir");
//		int lastSlash = path.lastIndexOf('\\');
//		path = path.substring(0, lastSlash);
		path += "\\";

	}

	@After public void tearDown () throws Exception
	{
		tester = null;
		path = null;
		//System.gc();
	}

	@Test public void testCompareTo () throws Exception
	{
		assertEquals(1, tester.compareToTester('a', 'b', 1, 1));
	}

	@Test public void testGetCode_h () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) 'h');
		int[] expectedCode = new int[] {1, 1, 1, 0};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_e () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) 'e');
		int[] expectedCode = new int[] {1, 1, 0, 1};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_l () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) 'l');
		int[] expectedCode = new int[] {0, 1};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_o () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) 'o');
		int[] expectedCode = new int[] {0, 0};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_w () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) 'w');
		int[] expectedCode = new int[] {1, 0, 0};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_r () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) 'r');
		int[] expectedCode = new int[] {1, 1, 1, 1};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_d () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) 'd');
		int[] expectedCode = new int[] {1, 1, 0, 0};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_SPACE () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester((int) ' ');
		int[] expectedCode = new int[] {1, 0, 1, 1};

		assertArrayEquals(actualCode, expectedCode);
	}

	@Test public void testGetCode_EOF () throws Exception
	{
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed.txt"));
		int[] actualCode = tester.getCodeTester(0);
		int[] expectedCode = new int[] {1, 0, 1, 0};

		assertArrayEquals(actualCode, expectedCode);
	}

	// compressing the same text file twice should result in the same text file
	@Test public void testCompressTextFileSameCompressed () throws Exception
	{
		// compress same file twice
		tester.compressFile(new File(path + "longJoke.txt"), new File(path + "compressed.txt"));
		tester.compressFile(new File(path + "longJoke.txt"), new File(path + "compressed2.txt"));

		// contents of compressed files should be equal
		assertTrue(compareTextFile(path + "compressed.txt", path + "compressed2.txt"));
	}

	// compressing two different text files should result in different files
	@Test public void testCompressTextFileDifferentCompressed () throws Exception
	{
		// compress two different files
		tester.compressFile(new File(path + "original.txt"), new File(path + "compressed1.txt"));
		tester.compressFile(new File(path + "frankenstein.txt"), new File(path + "compressed2.txt"));

		// check contents of compressed files, should be different
		assertEquals(false, compareTextFile(path + "compressed1.txt", path + "compressed2.txt"));
	}

	// decompressing the same compressed file twice should result in the same file
	@Test public void testDecompressTextFileSameCompressed () throws Exception
	{
		// compress file
		tester.compressFile(new File(path + "longJoke.txt"), new File(path + "compressed.txt"));

		// decompress same file twice
		tester.decompressFile(new File(path + "compressed.txt"), new File(path + "decompressed.txt"));
		tester.decompressFile(new File(path + "compressed.txt"), new File(path + "decompressed2.txt"));

		// contents of both files should be equal
		assertTrue(compareTextFile(path + "decompressed.txt", path + "decompressed2.txt"));
	}

	// decompressing two different files should result in different files
	@Test public void testDecompressTextFileDifferentCompressed () throws Exception
	{
		// compress two different files
		tester.compressFile(new File(path + "longJoke.txt"), new File(path + "compressed.txt"));
		tester.compressFile(new File(path + "frankenstein.txt"), new File(path + "compressed2.txt"));

		// decompress the files
		tester.decompressFile(new File(path + "compressed.txt"), new File(path + "decompressed.txt"));
		tester.decompressFile(new File(path + "compressed2.txt"), new File(path + "decompressed2.txt"));

		// check that files resulted in different contents
		assertFalse(compareTextFile(path + "decompressed.txt", path + "decompressed2.txt"));
	}

	// compressing a file and then decompressing a file should create a file identical in content to the original.
	@Test public void testCompressionDecompression () throws Exception
	{

		// compress file
		tester.compressFile(new File(path + "longJoke.txt"), new File(path + "compressed.txt"));
		// decompress file
		tester.decompressFile(new File(path + "compressed.txt"), new File(path + "decompressed.txt"));

		// check that original file contents are exactly the same as in decompressed file
		assertTrue(compareTextFile(path + "longJoke.txt", path + "decompressed.txt"));
	}

	// this is just a quick test to make sure the method written to compare text files for testing huffman compression works
	@Test public void testCompareTextFile () throws Exception
	{

		tester.compressFile(new File(path + "longJoke.txt"), new File(path + "compressed.txt"));
		tester.decompressFile(new File(path + "compressed.txt"), new File(path + "decompressed.txt"));

		assertTrue(compareTextFile(path + "longJoke.txt", path + "decompressed.txt"));
		assertFalse(compareTextFile(path + "longJoke.txt", path + "compressed.txt"));
	}

	/**
	 * reads in two text files, creates a string based on their content and compares their strings.
	 *
	 * @return - returns true if the text contained by both files are the same, otherwise returns false.
	 */
	private static boolean compareTextFile (String file1, String file2)
	{

		// open a scanner attached to file1
		try (BufferedReader scan = new BufferedReader(new FileReader(new File(file1)));
				BufferedReader scan2 = new BufferedReader(new FileReader(new File(file2))))
		{
			// the char in file 1
			int bufferedChar = 0;
			// the char in file 2
			int bufferedChar2 = 0;

			while ((scan.ready() && bufferedChar != -1) && (scan2.ready() && bufferedChar2 != -1))
			{
				bufferedChar = scan.read();
				bufferedChar2 = scan2.read();

				if (bufferedChar != bufferedChar2)
				{
					return false;
				}
			}

			return true;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		return false;
	}
}