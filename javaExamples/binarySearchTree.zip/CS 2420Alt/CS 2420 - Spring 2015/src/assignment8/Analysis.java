package assignment8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.TreeSet;

/**
 * Analysis timing code for assignment8 BinarySearchTrees
 * 
 * @author Aaron Bellis, Kory Hansen
 *
 */
public class Analysis
{

	private static final int beginningOrder = 1000;
	private static final int endingOrder = 10000;
	private static final long RANDOM_SEED = 55555;

	public static void main (String[] args)
	{
		TimingGrid grid = new TimingGrid("BinarySearchTree vs Java's TreeSet Timing");

		String path = System.getProperty("user.home") + "\\Desktop\\";
		String fileName = "BSTcontains.html";
		String fileAndPath = path + fileName;
		// System.out.println("Test remove average case");
		System.out.println();
		grid.add(testContainsSorted());
		//grid.add(testContainsRandom());
		// grid.add(testTreeSetContainsRandom());
		// grid.add(testAddRandom());
		// grid.add(testTreeSetAddRandom());
		// grid.add(testMyStackPeek());

		grid.writeHTML(fileAndPath);
	}

	private static TimingGroup testContainsSorted ()
	{
		// create TimingGroup
		TimingGroup thisGroup = new TimingGroup("BST contains, sorted set");

		// this test will run on increasingly sized sets, running multiple times
		// and providing the average runtime for the set size
		for (double mySetSizeTracker = beginningOrder; mySetSizeTracker < endingOrder; mySetSizeTracker += 100)
		{

			double setSize = mySetSizeTracker;// Math.pow(2, mySetSizeTracker);
			BinarySearchTree<Integer> set = new BinarySearchTree<Integer>();
			ArrayList<Integer> setList = new ArrayList<Integer>((int) setSize);
			for (int i = 0; i < setSize; i++)
			{
				setList.add(i);
			}
			set.addAll(setList);

			// MyLinkedList<Integer> set = new MyLinkedList<Integer>();
			// for (int i = 0; i < testSet.size(); i++)
			// set.addFirst(i);

			// the element in the list to get
			long indexToSearch = (long) setSize / 2;

			long startTime, midpointTime, stopTime;

			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.
			startTime = System.nanoTime();
			while (System.nanoTime() - startTime < 1000000000)
			{
				// empty block
			}
			// Now, run the test.

			startTime = System.nanoTime();

			long timesToLoop = 10000;

			for (long i = 0; i < timesToLoop; i++)
			{
				set.contains((int) indexToSearch);
			}

			midpointTime = System.nanoTime();
			// Run a loop to capture the cost of running the loop and
			// copying the ArrayList
			for (long i = 0; i < timesToLoop; i++)
			{

			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop;
			System.out.println("Running BinarySearchTree's contains on a sorted set of size "
					+ setSize + " took, on average " + averageTime + " nanoseconds (Average of "
					+ timesToLoop + " runs)");

			thisGroup.add(new TimingRecord("sorted contains()", (int) setSize, averageTime,
					"nanoseconds", timesToLoop));
		}

		return thisGroup;
	}

	private static TimingGroup testContainsRandom ()
	{
		// create TimingGroup
		TimingGroup thisGroup = new TimingGroup("BST contains, random set");

		// this test will run on increasingly sized sets, running multiple times
		// and providing the average runtime for the set size
		for (double mySetSizeTracker = beginningOrder; mySetSizeTracker < 21; mySetSizeTracker++)
		{

			double setSize = Math.pow(2, mySetSizeTracker);
			BinarySearchTree<Integer> set = new BinarySearchTree<Integer>();
			ArrayList<Integer> setList = new ArrayList<Integer>((int) setSize);
			for (int i = 0; i < setSize; i++)
			{
				setList.add(i);
			}
			Collections.shuffle(setList, new Random(RANDOM_SEED));
			set.addAll(setList);

			// MyLinkedList<Integer> set = new MyLinkedList<Integer>();
			// for (int i = 0; i < testSet.size(); i++)
			// set.addFirst(i);

			// the element in the list to get
			// long indexToSearch = (long) setSize / 2;

			long startTime, midpointTime, stopTime;

			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.
			startTime = System.nanoTime();
			while (System.nanoTime() - startTime < 1000000000)
			{
				// empty block
			}
			// Now, run the test.

			startTime = System.nanoTime();

			long timesToLoop = 1000;

			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
					set.contains((int) i);
			}

			midpointTime = System.nanoTime();
			// Run a loop to capture the cost of running the loop and
			// copying the ArrayList
			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
				{

				}
			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop / setSize;
			System.out.println("Running BinarySearchTree's contains on a random set of size "
					+ setSize + " took, on average " + averageTime + " nanoseconds (Average of "
					+ timesToLoop + " runs)");

			thisGroup.add(new TimingRecord("random contains()", (int) setSize, averageTime,
					"nanoseconds", timesToLoop));
		}

		return thisGroup;
	}

	private static TimingGroup testTreeSetContainsRandom ()
	{
		// create TimingGroup
		TimingGroup thisGroup = new TimingGroup("TreeSet contains, random set");

		// this test will run on increasingly sized sets, running multiple times
		// and providing the average runtime for the set size
		for (double mySetSizeTracker = beginningOrder; mySetSizeTracker < 21; mySetSizeTracker++)
		{

			double setSize = Math.pow(2, mySetSizeTracker);
			TreeSet<Integer> set = new TreeSet<Integer>();
			ArrayList<Integer> setList = new ArrayList<Integer>((int) setSize);
			for (int i = 0; i < setSize; i++)
			{
				setList.add(i);
			}
			Collections.shuffle(setList, new Random(RANDOM_SEED));
			set.addAll(setList);

			// MyLinkedList<Integer> set = new MyLinkedList<Integer>();
			// for (int i = 0; i < testSet.size(); i++)
			// set.addFirst(i);

			// the element in the list to get
			// long indexToSearch = (long) setSize / 2;

			long startTime, midpointTime, stopTime;

			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.
			startTime = System.nanoTime();
			while (System.nanoTime() - startTime < 1000000000)
			{
				// empty block
			}
			// Now, run the test.

			startTime = System.nanoTime();

			long timesToLoop = 10;

			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
					set.contains((int) i);
			}

			midpointTime = System.nanoTime();
			// Run a loop to capture the cost of running the loop and
			// copying the ArrayList
			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
				{

				}
			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop / setSize;
			System.out.println("Running TreeSet's contains on a random set of size "
					+ setSize + " took, on average " + averageTime + " nanoseconds (Average of "
					+ timesToLoop + " runs)");

			thisGroup.add(new TimingRecord("TreeSet contains()", (int) setSize, averageTime,
					"nanoseconds", timesToLoop));
		}

		return thisGroup;
	}

	private static TimingGroup testAddRandom ()
	{
		// create TimingGroup
		TimingGroup thisGroup = new TimingGroup("BST add, random set");

		// this test will run on increasingly sized sets, running multiple times
		// and providing the average runtime for the set size
		for (double mySetSizeTracker = beginningOrder; mySetSizeTracker < 21; mySetSizeTracker++)
		{

			double setSize = Math.pow(2, mySetSizeTracker);
			BinarySearchTree<Integer> set = new BinarySearchTree<Integer>();
			ArrayList<Integer> setList = new ArrayList<Integer>((int) setSize);
			for (int i = 0; i < setSize; i++)
			{
				setList.add(i);
			}
			Collections.shuffle(setList, new Random(RANDOM_SEED));

			// MyLinkedList<Integer> set = new MyLinkedList<Integer>();
			// for (int i = 0; i < testSet.size(); i++)
			// set.addFirst(i);

			// the element in the list to get
			// long indexToSearch = (long) setSize / 2;

			long startTime, midpointTime, stopTime;

			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.
			startTime = System.nanoTime();
			while (System.nanoTime() - startTime < 1000000000)
			{
				// empty block
			}
			// Now, run the test.

			startTime = System.nanoTime();

			long timesToLoop = 10;

			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
				{
					set.add(setList.get((int)j));
				}
			}

			midpointTime = System.nanoTime();
			// Run a loop to capture the cost of running the loop and
			// copying the ArrayList
			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
				{
					setList.get((int)j);
				}
			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop / setSize;
			System.out.println("Running BinarySearchTree's add on a random set of size "
					+ setSize + " took, on average " + averageTime + " nanoseconds (Average of "
					+ timesToLoop + " runs)");

			thisGroup.add(new TimingRecord("BST add()", (int) setSize, averageTime,
					"nanoseconds", timesToLoop));
		}

		return thisGroup;
	}
	
	private static TimingGroup testTreeSetAddRandom ()
	{
		// create TimingGroup
		TimingGroup thisGroup = new TimingGroup("TreeSet Add, random set");

		// this test will run on increasingly sized sets, running multiple times
		// and providing the average runtime for the set size
		for (double mySetSizeTracker = beginningOrder; mySetSizeTracker < 21; mySetSizeTracker++)
		{

			double setSize = Math.pow(2, mySetSizeTracker);
			TreeSet<Integer> set = new TreeSet<Integer>();
			ArrayList<Integer> setList = new ArrayList<Integer>((int) setSize);
			for (int i = 0; i < setSize; i++)
			{
				setList.add(i);
			}
			Collections.shuffle(setList, new Random(RANDOM_SEED));

			// MyLinkedList<Integer> set = new MyLinkedList<Integer>();
			// for (int i = 0; i < testSet.size(); i++)
			// set.addFirst(i);

			// the element in the list to get
			// long indexToSearch = (long) setSize / 2;

			long startTime, midpointTime, stopTime;

			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.
			startTime = System.nanoTime();
			while (System.nanoTime() - startTime < 1000000000)
			{
				// empty block
			}
			// Now, run the test.

			startTime = System.nanoTime();

			long timesToLoop = 10;

			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
				{
					set.add(setList.get((int)j));
				}
			}

			midpointTime = System.nanoTime();
			// Run a loop to capture the cost of running the loop and
			// copying the ArrayList
			for (long i = 0; i < timesToLoop; i++)
			{
				for (long j = 1; j < setSize; j++)
				{
					setList.get((int)j);
				}
			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop / setSize;
			System.out.println("Running TreeSet add on a random set of size "
					+ setSize + " took, on average " + averageTime + " nanoseconds (Average of "
					+ timesToLoop + " runs)");

			thisGroup.add(new TimingRecord("TreeSet add()", (int) setSize, averageTime,
					"nanoseconds", timesToLoop));
		}

		return thisGroup;
	}
}
