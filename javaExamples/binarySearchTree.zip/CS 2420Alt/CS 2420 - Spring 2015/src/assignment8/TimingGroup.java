package assignment8;

import java.util.ArrayList;

/**
 * A class for keeping related timing records sorted into a group
 * @author Aaron Bellis
 *
 */
public class TimingGroup
{
	private ArrayList<TimingRecord> records;
	private String groupTitle;
	
	public TimingGroup(String title)
	{
		records = new ArrayList<TimingRecord>();
		groupTitle = title;
	}
	
	public String getGroupTitle()
	{
		return groupTitle;
	}
	
	public ArrayList<TimingRecord> getTimingRecords()
	{
		return records;
	}
	
	public long[] getSetSizes()
	{
		long[] setSizes = new long[records.size()];
		for (int i = 0; i < setSizes.length; i++)
		{
			setSizes[i] = records.get(i).getSetSize();
		}
		return setSizes;
	}
	
	public double[] getTimes()
	{
		double[] times = new double[records.size()];
		for (int i = 0; i < times.length; i++)
		{
			times[i] = records.get(i).getTime();
		}
		return times;
	}
	
	public int getSize()
	{
		return records.size();
	}
	
	public void add(TimingRecord record)
	{
		records.add(record);
	}
	
	public boolean hasSetSize(Long n)
	{
		for (TimingRecord record: records)
		{
			if (record.getTime() ==n)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public TimingRecord getTimingRecord (int record)
	{
		return records.get(record);
	}
}
