package assignment8;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.NoSuchElementException;

/**
 * BinarySearchTree class represents a Binary Search Tree whose items are
 * ordered using their natural ordering (i.e., each item must be Comparable) and
 * implements the SortedSet interface and, as a set, will contain no duplicates.
 * 
 * @author Aaron Bellis, Kory Hansen
 */
public class BinarySearchTree<Type extends Comparable<? super Type>> implements SortedSet<Type>
{
	private Node<Type> root;
	private int size;

	/**
	 * Creates an empty BST
	 */
	public BinarySearchTree ()
	{
		root = null;
		size = 0;
	}

	/**
	 * Adds an item to the BST if it is not present already. This is a driver
	 * method for the recursive add method.
	 * 
	 * @param item
	 *            - the item to be added
	 * @return true if this set changed as a result of this method call (that
	 *         is, if the input item was actually inserted); otherwise, returns
	 *         false
	 * @throws NullPointerException
	 *             if the item is null
	 */
	@Override
	public boolean add (Type item)
	{
		if (item == null)
			throw new NullPointerException();

		if (size == 0) // if empty list, the item is now stored in the root of
						// the tree
		{
			root = new Node<Type>(item, null, null);
			size++;
			return true;
		}
		else
		{
			Node<Type> current = root;
			return add(item, current); // Begin recursion
		}

	}

	/**
	 * Recursive add method.
	 * 
	 * @param item
	 *            the element to be inserted
	 * @param current
	 *            the root of the current subtree that is examined in the
	 *            particular method call
	 * @return true if the item was added, false if not
	 */
	private boolean add (Type item, Node<Type> current)
	{
		
		if (item.compareTo(current.nodeData) < 0)
		{
			// If we found an empty spot (null), put the item there
			if (current.leftChild == null)
			{
				current.leftChild = new Node<Type>(item, null, null);
				size++;
				return true;
			}
			else
				return add(item, current.leftChild);
		}
		else if (item.compareTo(current.nodeData) > 0)
		{
			// If we found an empty spot (null), put the item there
			if (current.rightChild == null)
			{
				current.rightChild = new Node<Type>(item, null, null);
				size++;
				return true;
			}
			else
				return add(item, current.rightChild);
		}

		return false;
	}

	/**
	 * Adds all of the items in a collection to the BST.
	 * 
	 * @param items
	 *            - the collection of items to be added
	 * @return true if this set changed as a result of this method call (that
	 *         is, if any items in the input collection were actually inserted);
	 *         otherwise, returns false
	 * @throws NullPointerException
	 *             if any of the items is null
	 */
	@Override
	public boolean addAll (Collection<? extends Type> items)
	{
		boolean changedTree = false;

		for (Type item : items)
		{
			if (add(item))
				changedTree = true;
		}
		return changedTree;
	}

	/**
	 * Removes all items from this set. The set will be empty after this method
	 * call.
	 */
	@Override
	public void clear ()
	{
		root = null;
		size = 0;
	}

	/**
	 * Determines if there is an item in this set that is equal to the specified
	 * item.
	 * 
	 * @param item
	 *            - the item sought in this set
	 * @return true if there is an item in this set that is equal to the input
	 *         item; otherwise, returns false
	 * @throws NullPointerException
	 *             if the item is null
	 */
	@Override
	public boolean contains (Type item)
	{
		if (item == null)
			throw new NullPointerException();

		Node<Type> current = root;

		while (current.nodeData.compareTo(item) != 0)
		{

			if (current.nodeData.compareTo(item) < 0 && current.hasRightChild())
				current = current.rightChild;
			else if (current.nodeData.compareTo(item) > 0 && current.hasLeftChild())
				current = current.leftChild;
			else
				return false;
		}
		return true;
	}

	/**
	 * Determines if for each item in the specified collection, there is an item
	 * in this set that is equal to it.
	 * 
	 * @param items
	 *            - the collection of items sought in this set
	 * @return true if for each item in the specified collection, there is an
	 *         item in this set that is equal to it; otherwise, returns false
	 * @throws NullPointerException
	 *             if any of the items is null
	 */
	@Override
	public boolean containsAll (Collection<? extends Type> items)
	{
		for (Type item : items)
		{
			// if one of the items was null throw exception
			if (item == null)
				throw new NullPointerException();

			if (!contains(item))
				return false;
		}
		return true;
	}

	/**
	 * Returns the first (i.e., smallest) item in this set.
	 * 
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public Type first () throws NoSuchElementException
	{
		if (isEmpty())
			throw new NoSuchElementException();

		return root.getLeftmostChild().nodeData;
	}

	/**
	 * Returns true if this set contains no items.
	 */
	@Override
	public boolean isEmpty ()
	{
		return size == 0 && root == null;
	}

	/**
	 * Returns the last (i.e., largest) item in this set.
	 * 
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public Type last () throws NoSuchElementException
	{
		if (isEmpty())
			throw new NoSuchElementException();

		return root.getRightmostChild().nodeData;
	}

	/**
	 * Removes the specified item from the BST. This is a driver method for our
	 * recursive remove algorithm.
	 * 
	 * @param item
	 *            - the item to be removed
	 * @return true if this set changed as a result of this method call (that
	 *         is, if the input item was actually removed); otherwise, returns
	 *         false
	 * @throws NullPointerException
	 *             if the item is null
	 */
	@Override
	public boolean remove (Type item)
	{
		if (item == null)
			throw new NullPointerException();

		if (size == 0) // Can't remove a nonexistent element
		{
			return false;
		}

		if (root.nodeData == item) // If the root is the desired element to
									// remove
		{
			if (size == 1)
			{
				this.clear();
				return true;
			}
			Node<Type> current = root.rightChild.getLeftmostChild();
			Type temp = current.nodeData;
			remove(current.nodeData);
			root.nodeData = temp;
			return true;
		}

		// Get the parent of the item to be removed, parent will be null if item
		// doesn't exist in set
		Node<Type> parent = getParent(root, item);

		// call our recursive remove method on subtree which starts at parent
		if (remove(parent, item) != null) // If we actually removed something...
		{
			size--;
			return true;
		}
		else
			return false;
	}

	/**
	 * Recursive method for removing items from a tree, or subtree.
	 * 
	 * @param node
	 *            - the node which represents the root of the subtree to be
	 *            removed
	 * @param item
	 *            - the item to be removed from the subtree
	 * @return Returns null if the node being passed to the method is null, else
	 *         returns the root node of the subtree after the item has been
	 *         removed
	 */
	private Node<Type> remove (Node<Type> node, Type item)
	{
		// avoid null pointer exceptions
		if (node == null)
			return null;

		// if item is less than current node data, recurse left
		if (item.compareTo(node.nodeData) < 0)
		{
			node.leftChild = remove(node.leftChild, item);
		}
		// if item is greater than current node data, recurse right
		else if (item.compareTo(node.nodeData) > 0)
		{
			node.rightChild = remove(node.rightChild, item);
		}
		// node data is neither less than nor greater than, so it must be equal
		// to and we found it, time to do the work.

		// check if node has two children
		else if (node.leftChild != null && node.rightChild != null)
		{
			// get the smallest value node of the right sub tree, which is the
			// successor
			Node<Type> successor = node.rightChild.getLeftmostChild();
			// swap the data in the successor and the node to remove
			node.nodeData = successor.nodeData;
			// remove the successor from right subtree
			node.rightChild = remove(node.rightChild, successor.nodeData);
		}
		// node has one or fewer subtrees
		else
		{
			// if node has a left subtree replace current node with it's left
			// child
			if (node.leftChild != null)
			{
				node = node.leftChild;
			}
			// node doesn't have a left sub tree, set node to right sub tree
			// if node doesn't have a right sub tree, it was a leaf and can be
			// set to null which will be the value of its right subtree
			else
			{
				node = node.rightChild;
			}
		}

		return node;
	}

	/**
	 * Returns the Node which is parent to a Node that contains item as its
	 * data.
	 * 
	 * @param node
	 *            - the highest node in the subtree to be searched
	 * @param item
	 *            - the data of the child node to be found
	 * @return Null if the item does not exist in the tree, otherwise returns
	 *         the Node which is parent to the Node containing the specified
	 *         item.
	 */
	private Node<Type> getParent (Node<Type> node, Type item)
	{
		// initialize parent to null
		Node<Type> parent = null;

		// keep looking downward until we have found the item, node becomes null
		// (item is not in list)
		while (node != null && !node.nodeData.equals(item))
		{
			// if the item is less than, go left
			if (item.compareTo(node.nodeData) < 0)
			{
				// parent gets set to current node
				parent = node;
				// node goes down one level
				node = node.leftChild;
			}
			// if the item is greater than, go right
			else if (item.compareTo(node.nodeData) > 0)
			{
				// parent gets set to current node
				parent = node;
				// node goes down one level
				node = node.rightChild;
			}
		}

		if (node == null) // item wasn't found, return null
		{
			return null;
		}
		// item was found return its parent (parent is null if the top node was
		// the item we were looking for)
		else
		{
			return parent;
		}
	}

	/**
	 * Removes all of the elements in the collection from the BST, if they exist
	 * 
	 * @param items
	 *            - the collection of items whose absence is ensured in this set
	 * @return true if this set changed as a result of this method call (that
	 *         is, if any item in the input collection was actually removed);
	 *         otherwise, returns false
	 * @throws NullPointerException
	 *             if any of the items is null
	 */
	@Override
	public boolean removeAll (Collection<? extends Type> items)
	{
		boolean changedTree = false;

		// loop through collection, if one item was removed update changedTree
		for (Type item : items)
		{
			if (remove(item))
				changedTree = true;
		}
		return changedTree;
	}

	/**
	 * Returns the number of items in this set.
	 */
	@Override
	public int size ()
	{
		return size;
	}

	/**
	 * Returns an ArrayList containing all of the items in this set, in sorted
	 * order.
	 */
	@Override
	public ArrayList<Type> toArrayList ()
	{
		// create ArrayList of the size of our tree, so that it won't have to
		// grow underlying array
		ArrayList<Type> myArray = new ArrayList<Type>(size);
		Node<Type> current = root;
		toArrayList(current, myArray);
		return myArray;
	}

	/**
	 * Recursive function for putting items into an array list
	 * 
	 * @param current
	 *            the node currently being visited
	 * @param myArray
	 *            the array to which elements will be added
	 */
	private void toArrayList (Node<Type> current, ArrayList<Type> myArray)
	{
		// base case
		if (current == null)
			return;

		// in order DFT
		toArrayList(current.leftChild, myArray);
		myArray.add(current.nodeData);
		toArrayList(current.rightChild, myArray);
	}

	/**
	 * Internal class that implements a node. Each node contains data and points
	 * to the left and right children.
	 */
	private class Node<Type>
	{
		// the left child of this node
		private Node<Type> leftChild;
		// the right child of this node
		private Node<Type> rightChild;
		// The data the node contains
		private Type nodeData;

		/**
		 * Constructor for the Node class. Initializes fields for data and left
		 * and right children.
		 * 
		 * @param data
		 *            the data that the node contains
		 * @param left
		 *            the left child of this node
		 * @param right
		 *            the right child of this node
		 */
		private Node (Type data, Node<Type> left, Node<Type> right)
		{
			nodeData = data;
			leftChild = left;
			rightChild = right;
		}

		/**
		 * Determines if this node has a left child
		 * 
		 * @return true if this node has a left child, false if not
		 */
		private boolean hasLeftChild ()
		{
			return leftChild != null;
		}

		/**
		 * Determines if this node has a right child
		 * 
		 * @return true if this node has a right child, false if not
		 */
		private boolean hasRightChild ()
		{
			return rightChild != null;
		}

		/**
		 * Recursive function that retrieves the memory address of the smallest
		 * descendant of this node.
		 * 
		 * @return the smallest descendant of this node
		 */
		private Node<Type> getLeftmostChild ()
		{
			if (!this.hasLeftChild())
				return this;

			return this.leftChild.getLeftmostChild();
		}

		/**
		 * Recursive function that retrieves the memory address of the largest
		 * descendant of this node.
		 * 
		 * @return the largest descendant of this node
		 */
		private Node<Type> getRightmostChild ()
		{
			if (!this.hasRightChild())
				return this;

			return this.rightChild.getRightmostChild();
		}
	}

	// Driver for writing this tree to a dot file
	public void writeDot (String filename)
	{
		try
		{
			// PrintWriter(FileWriter) will write output to a file
			PrintWriter output = new PrintWriter(new FileWriter(filename));

			// Set up the dot graph and properties
			output.println("digraph BST {");
			output.println("node [shape=record]");

			if (size != 0)
				writeDotRecursive(root, output);
			// Close the graph
			output.println("}");
			output.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// Recursive method for writing the tree to a dot file
	private void writeDotRecursive (Node<Type> n, PrintWriter output)
			throws Exception
	{
		output.println(n.nodeData + "[label=\"<L> |<D> " + n.nodeData + "|<R> \"]");
		if (n.leftChild != null)
		{
			// write the left subtree
			writeDotRecursive(n.leftChild, output);

			// then make a link between n and the left subtree
			output.println(n.nodeData + ":L -> " + n.leftChild.nodeData + ":D");
		}
		if (n.rightChild != null)
		{
			// write the left subtree
			writeDotRecursive(n.rightChild, output);

			// then make a link between n and the right subtree
			output.println(n.nodeData + ":R -> " + n.rightChild.nodeData + ":D");
		}

	}

}
