package assignment8;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit test class for SpellChecker
 * @author Kory Hansen and Aaron Bellis
 *
 */
public class SpellCheckerTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	//Make sure SpellChecker can create a dictionary from a list and use it properly
	@Test
	public void testSpellCheckerListOfString() {
		List<String> arbDict = new ArrayList<String>(); //arb = arbitrary
		arbDict.add("this");
		arbDict.add("is");
		arbDict.add("a");
		arbDict.add("test");
		arbDict.add("of");
		arbDict.add("the");
		arbDict.add("emergency");
		arbDict.add("alert");
		arbDict.add("system");
		SpellChecker ourSC = new SpellChecker (arbDict);
		List<String> expected = new ArrayList<String>();
		expected.add("not");
		expected.add("even");
		expected.add("close");
		expected.add("to");
		File testFile = new File("teststringlist.txt");
		assertArrayEquals(expected.toArray(), ourSC.spellCheck(testFile).toArray());
	}

	//Make sure SpellChecker can construct a dictionary from a file and use it
	@Test
	public void testSpellCheckerFile() {
		File dict = new File("dictionary.txt");
		SpellChecker ourSC = new SpellChecker (dict);
		File testFile = new File("testfile.txt");
		assertEquals(21, ourSC.spellCheck(testFile).toArray().length);
	}

	//Make sure adding nonsense words to the dictionary are recognized in a document full of 
	//nonsense words
	@Test
	public void testAddToDictionary() {
		File dict = new File("dictionary.txt");
		SpellChecker ourSC = new SpellChecker (dict);
		File testFile = new File("testfile.txt");
		ourSC.addToDictionary("rite");
		ourSC.addToDictionary("brane");
		assertEquals(19, ourSC.spellCheck(testFile).toArray().length);
	}

	//Make sure removing words from the dictionary causes the SC to flag the removed words 
	//when checking the original dictionary
	@Test
	public void testRemoveFromDictionary() {
		File dict = new File("dictionary.txt");
		SpellChecker ourSC = new SpellChecker (dict);
		File testFile = new File("dictionary.txt");
		ourSC.removeFromDictionary("melancholic");
		ourSC.removeFromDictionary("pulverizer");
		ourSC.removeFromDictionary("kitchens");
		ourSC.removeFromDictionary("fox");
		assertEquals(4, ourSC.spellCheck(testFile).toArray().length);
	}

}
