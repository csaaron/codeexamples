package assignment8;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

/**
 * 
 * @author Aaron Bellis, Kory Hansen
 *
 */
public class DotWriter
{

	private static final int RANDOM_SET_SIZE = 10;

	public static void main (String[] args)
	{

		// set up string for file path
		String path = System.getProperty("user.home");
		path += "\\Desktop";
		String fileName = ("BST.dot");
		String longFileName = path + "\\" + fileName;

		// create binary search tree
		BinarySearchTree<Integer> bst1 = new BinarySearchTree<Integer>();

		int size = (int)Math.pow(2, 20);
		ArrayList<Integer> intList = new ArrayList<Integer>(size);
		for (int i =0; i< size; i++)
		{
			intList.add(i);
		}
		
		bst1.addAll(intList);
		
		System.out.println("Done");
		
//		ArrayList<Integer> randomSet = new ArrayList<Integer>();
//		while (randomSet.size() < RANDOM_SET_SIZE)
//		{
//			randomSet.add((int) (Math.random() * (RANDOM_SET_SIZE * 10)));
//		}
//
//		bst1.addAll(randomSet);

		// write dot file
		//bst1.writeDot(longFileName);

	}

}
