package assignment8;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

public class TimingGrid
{
	private ArrayList<TimingGroup> groups;
	private TreeSet<Long> setSizes;
	private String title;

	public TimingGrid (String gridTitle)
	{
		title = gridTitle;
		groups = new ArrayList<TimingGroup>();
		setSizes = new TreeSet<Long>();
	}

	public void add (TimingGroup records)
	{
		groups.add(records);
		long[] sizes = records.getSetSizes();
		for (long size : sizes)
		{
			setSizes.add(size);
		}
	}

	public void printGrid ()
	{
		// print the title to the grid
		System.out.println(title);
		System.out.println("Time in "
				+ groups.get(0).getTimingRecord(0).getTimeUnit());
		System.out.println("Times looped "
				+ groups.get(0).getTimingRecord(0).getTimesLooped());
		System.out.println();

		String[][] data = getRecordGrid();
		for (int row = 0; row < data.length; row++)
		{
			for (int column = 0; column < data[row].length; column++)
			{
				System.out.printf("%s\t", data[row][column]);
			}
			System.out.println();
		}
	}

	public void writeGrid (String filename)
	{

		File thisFile = new File(filename);

		try (PrintStream file = new PrintStream(thisFile))
		{
			// print the title to the grid
			file.println(title);
			file.println("Time in "
					+ groups.get(0).getTimingRecord(0).getTimeUnit());
			file.println("Times looped "
					+ groups.get(0).getTimingRecord(0).getTimesLooped());
			file.println();

			String[][] data = getRecordGrid();
			for (int row = 0; row < data.length; row++)
			{
				for (int column = 0; column < data[row].length; column++)
				{
					file.printf("%s\t", data[row][column]);
				}
				file.println();
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}

	private String[][] getRecordGrid ()
	{
		String[][] grid = new String[setSizes.size() + 1][groups.size() + 1];
		ArrayList<Long> setArray = new ArrayList<Long>(setSizes);

		// add set title heading to matrix
		grid[0][0] = "Set Size";
		// add the set sizes to column 0
		for (int row = 1; row < grid.length; row++)
		{
			grid[row][0] = String.format("%d", setArray.get(row - 1));
		}

		// add records to the grid
		for (int column = 1; column < grid[0].length; column++)
		{
			// put add the titles to row 0
			TimingGroup currentGroup = groups.get(column - 1);
			grid[0][column] = currentGroup.getGroupTitle();

			int offset = 1;
			for (int row = 1; row < grid.length; row++)
			{

				// get the size of the set to make sure it is the same as in
				// column0
				if (row - offset < currentGroup.getSize())
				{
					String setSize = String.format("%d", currentGroup
							.getTimingRecord(row - offset).getSetSize());

					// if set sizes match, add the time to the grid
					if (grid[row][0].equals(setSize))
					{
						grid[row][column] = String.format("%.1f", currentGroup
								.getTimingRecord(row - offset).getTime());
					}
					else
					{
						grid[row][column] = "";
						offset++;
					}
				}
				else
				{
					grid[row][column] = "";
				}
			}
		}

		return grid;
	}

	public TimingGrid readTimingGrid (String fileName)
	{
		TimingGrid newGrid = new TimingGrid("empty");
		try (Scanner myScanner = new Scanner(new File(fileName)))
		{

			// read in the title
			String title = "";
			if (myScanner.hasNextLine())
				title = myScanner.nextLine();

			// read in the unit
			String line = "";
			if (myScanner.hasNextLine())
				line = myScanner.nextLine();
			String[] splitString = line.split(" ");
			String unit = splitString[splitString.length - 1];

			// read in the times looped
			if (myScanner.hasNextLine())
				line = myScanner.nextLine();
			splitString = line.split(" ");
			long timesLooped = Long
					.parseLong(splitString[splitString.length - 1]);

			// next line is blank
			if (myScanner.hasNextLine())
				line = myScanner.nextLine();

			// read in the titles
			if (myScanner.hasNextLine())
				line = myScanner.nextLine();
			String[] titles = line.split("\t");

			// create groups for each record to go into
			ArrayList<TimingGroup> newGroups = new ArrayList<TimingGroup>();
			for (int i = 1; i < titles.length; i++)
			{
				newGroups.add(new TimingGroup(titles[i]));
			}

			while (myScanner.hasNextLine())
			{
				// read in each line
				line = myScanner.nextLine();
				// split the line up delimited by a tab character
				splitString = line.split("\t");
				// get the set size from the first column
				long setSize = Long.parseLong(splitString[0]);
				// iterate through each column
				for (int i = 1; i < splitString.length; i++)
				{
					// get the record name from the matching column
					String recordName = titles[i];
					// make sure wasn't a record that had no timing
					if (!splitString[i].equals(""))
					{
						// parse the time to complete
						double timeToComplete = Double
								.parseDouble(splitString[i]);
						// create a record with the info
						TimingRecord record = new TimingRecord(recordName,
								setSize, timeToComplete, unit, timesLooped);
						// add the record to the group. Will be i-1 because
						// there is no record for column 0
						newGroups.get(i - 1).add(record);
					}
				}
			}
			newGrid = new TimingGrid(title);
			for (TimingGroup group : newGroups)
			{
				newGrid.add(group);
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}

		return newGrid;
	}

	public void addGroupToFile (String fileName, TimingGroup group)
	{
		TimingGrid file = readTimingGrid(fileName);
		file.add(group);
		file.writeGrid(fileName);
	}
	
	public void writeHTML(String fileName)
	{
		File thisFile = new File(fileName);

		try (PrintStream file = new PrintStream(thisFile))
		{
			file.print(HTMLheader());
			
			file.println("<body>");
			file.println("<p>");
			
			// print the title to the grid
			String br = " </br>";
			file.println(title + br);
			
			file.println("Time in "
					+ groups.get(0).getTimingRecord(0).getTimeUnit() +br);
			file.println("Times looped "
					+ groups.get(0).getTimingRecord(0).getTimesLooped() + br);
			file.println("</p>");

			file.println("<table class=\"data\">");
			String[][] data = getRecordGrid();
			for (int row = 0; row < data.length; row++)
			{
				file.println("<tr>");
				for (int column = 0; column < data[row].length; column++)
				{
					String cssClass = column == 0 || row == 0 ? "class =\"highlight\"" : "";
					String tdTag = "<td " + cssClass + ">";
					String closeTag = "</td>";
					file.printf("\t%s%s%s%n", tdTag,data[row][column],closeTag);
				}
				file.println("\n</tr>");
			}
			file.println("</table>");
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}

	}

	private String HTMLheader ()
	{
		String header = "";
		String nl = "\n";
		header += "<html>" + nl;
		header += "<head>" + nl;
		header += "<title>" + title + "</title>" + nl;
		// css will go here
		header += "</head>" + nl;
			
		return header;
	}
}
