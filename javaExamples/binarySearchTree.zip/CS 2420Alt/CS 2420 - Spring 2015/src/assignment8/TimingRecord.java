package assignment8;

/**
 * A class to story method and data structure timing data. 
 * 
 * @author Aaron Bellis
 *
 */
public class TimingRecord
{
	private String title;
	private long nSize;
	private double time;
	private String unit;
	private long looped;

	public TimingRecord (String recordTitle, long setSize,
			double timeToComplete, String timeUnit, long timesLooped)
	{
		title = recordTitle;
		nSize = setSize;
		time = timeToComplete;
		unit = timeUnit;
		looped = timesLooped;
	}
	
	public String getTitle()
	{
		return title;
	}
	
	public long getSetSize()
	{
		return nSize;
	}

	public double getTime()
	{
		return time;
	}
	
	public String getTimeUnit()
	{
		return unit;
	}
	
	public long getTimesLooped()
	{
		return looped;
	}
}
