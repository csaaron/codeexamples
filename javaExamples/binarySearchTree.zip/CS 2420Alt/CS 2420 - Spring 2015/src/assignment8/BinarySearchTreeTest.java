package assignment8;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit testing for the BinarySearchTree class.
 * 
 * @author Kory Hansen and Aaron Bellis
 *
 */
public class BinarySearchTreeTest
{
	private BinarySearchTree<Integer> bst1;
	private static final int RANDOM_SET_SIZE = 10;

	@Before
	public void setUp () throws Exception
	{
		bst1 = new BinarySearchTree<Integer>();
	}

	@After
	public void tearDown () throws Exception
	{
		bst1 = null;
	}

	// Make sure our constructor actually makes an empty BST
	@Test
	public void testBinarySearchTreeConstructorSize ()
	{
		bst1 = new BinarySearchTree<Integer>();
		assertEquals(0, bst1.size());
	}

	// Make sure that our BST size and root are properly changed when adding one
	// item
	@Test
	public void testAddOneItem ()
	{
		assertTrue(bst1.add(1));
		assertEquals(1, bst1.size());
		assertEquals((Integer) 1, bst1.first());
		assertEquals((Integer) 1, bst1.last());
	}

	// Make sure duplicate items don't get added
	@Test
	public void testAddDuplicateItemBoolean ()
	{
		bst1.add(1);
		assertFalse(bst1.add(1));
		assertEquals(1, bst1.size());
		assertEquals((Integer) 1, bst1.first());
		assertEquals((Integer) 1, bst1.last());
	}

	// Make sure our add method throws the proper exception
	@Test (expected = NullPointerException.class)
	public void testAddException ()
	{
		bst1.add(1);
		bst1.add(null);
	}

	// Another duplicate item test
	@Test
	public void testAddDuplicateItems ()
	{
		bst1.add(3);
		bst1.add(2);
		bst1.add(5);
		assertFalse(bst1.add(3));
		assertEquals(3, bst1.size());
		assertEquals((Integer) 2, bst1.first());
		assertEquals((Integer) 5, bst1.last());
	}

	// Ensure that our BST matches our expectations element-for-element
	@Test
	public void testAddResultArray ()
	{
		bst1.add(3);
		bst1.add(2);
		bst1.add(5);
		bst1.add(1);
		bst1.add(9);

		ArrayList<Integer> resultsList = bst1.toArrayList();
		int[] resultsArray = new int[resultsList.size()];
		for (int i = 0; i < resultsArray.length; i++)
		{
			resultsArray[i] = resultsList.get(i);
		}
		int[] expectedArray = {1, 2, 3, 5, 9};

		assertArrayEquals(expectedArray, resultsArray);
		assertEquals(5, bst1.size());
		assertEquals((Integer) 1, bst1.first());
		assertEquals((Integer) 9, bst1.last());
	}

	// Same as above, but with a duplicate element that is not added
	@Test
	public void testAddResultArrayWithDupe ()
	{
		bst1.add(3);
		bst1.add(2);
		bst1.add(5);
		bst1.add(1);
		bst1.add(9);
		bst1.add(2);

		ArrayList<Integer> resultsList = bst1.toArrayList();
		int[] resultsArray = new int[resultsList.size()];
		for (int i = 0; i < resultsArray.length; i++)
		{
			resultsArray[i] = resultsList.get(i);
		}
		int[] expectedArray = {1, 2, 3, 5, 9};

		assertArrayEquals(expectedArray, resultsArray);
		assertEquals(5, bst1.size());
		assertEquals((Integer) 1, bst1.first());
		assertEquals((Integer) 9, bst1.last());
	}

	// Ensure addAll works as expected
	@Test
	public void testAddAllAddOneCollection ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// tree changed so should return true
		assertTrue(bst1.addAll(toAddList));
		assertEquals(5, bst1.size());
		assertEquals((Integer) 1, bst1.first());
		assertEquals((Integer) 9, bst1.last());
	}

	// Make sure addAll works exactly as expected, element-for-element
	@Test
	public void testAddAllAddOneCollectionCheckItems ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// call addAll
		bst1.addAll(toAddList);

		// this should be the items in order from bst1
		int[] resultArray = {1, 2, 3, 5, 9};
		// the actual elements in the bst in ascending order
		ArrayList<Integer> actualsList = bst1.toArrayList();
		int[] actualsArray = new int[actualsList.size()];
		for (int i = 0; i < actualsArray.length; i++)
		{
			actualsArray[i] = actualsList.get(i);
		}

		assertArrayEquals(resultArray, actualsArray);
	}

	// Make sure addAll can properly handle two very similar collections
	@Test
	public void testAddAllAddTwoCollectionCheckItems ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// call addAll
		bst1.addAll(toAddList);

		// do same as above with an array which contains 1 additional item to
		// place into tree
		toAddArray = new int[] {3, 2, 5, 1, 9, 6};
		toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}
		// call addAll again
		bst1.addAll(toAddList);

		// this should be the items in order from bst1
		int[] resultArray = {1, 2, 3, 5, 6, 9};

		// the actual elements in the bst in ascending order
		ArrayList<Integer> actualsList = bst1.toArrayList();
		int[] actualsArray = new int[actualsList.size()];
		for (int i = 0; i < actualsArray.length; i++)
		{
			actualsArray[i] = actualsList.get(i);
		}

		assertArrayEquals(resultArray, actualsArray);
	}

	// Basically the same as above
	@Test
	public void testAddAllAddTwoCollection ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}
		// call addAll
		bst1.addAll(toAddList);

		// do same as above with an array which contains 1 additional item to
		// place into tree
		toAddArray = new int[] {3, 2, 5, 1, 9, 6};
		toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// tree changed as a result of adding an item, should return true
		assertTrue(bst1.addAll(toAddList));
	}

	// Make sure that adding two identical collections to the BST does not
	// change the BST
	// the second time
	@Test
	public void testAddAllAddTwoCollectionNoChange ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}
		// call addAll
		bst1.addAll(toAddList);

		// calling addAll with same data, tree should not change and should
		// return false
		assertFalse(bst1.addAll(toAddList));
	}

	// A more thorough item-by-item test of addAll
	@Test
	public void testAddAllAddTwoCollectionNoChangeCheckItems ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// call addAll
		bst1.addAll(toAddList);
		bst1.addAll(toAddList);

		// this should be the items in order from bst1
		int[] resultArray = {1, 2, 3, 5, 9};

		// the actual elements in the bst in ascending order
		ArrayList<Integer> actualsList = bst1.toArrayList();
		int[] actualsArray = new int[actualsList.size()];
		for (int i = 0; i < actualsArray.length; i++)
		{
			actualsArray[i] = actualsList.get(i);
		}

		assertArrayEquals(resultArray, actualsArray);
	}

	// Make sure addAll throws a NullPointerException when appropriate
	@Test (expected = NullPointerException.class)
	public void testAddAllException ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// add a null to the middle of arrayList
		toAddList.add(toAddList.size() / 2, null);

		// call addAll should throw exception
		bst1.addAll(toAddList);
	}

	// Make sure clear sets the size of the BST to 0
	@Test
	public void testClearSize ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// tree changed so should return true
		bst1.addAll(toAddList);

		bst1.clear();
		assertEquals(0, bst1.size());
	}

	// Make sure adding an item immediately after clear works properly
	@Test
	public void testClearSizeAddAgain ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// tree changed so should return true
		bst1.addAll(toAddList);

		bst1.clear();
		bst1.add(1);
		assertEquals(1, bst1.size());
	}

	// Tests toArrayList and clear together
	@Test
	public void testClearToArrayList ()
	{
		// create an array
		int[] toAddArray = {3, 2, 5, 1, 9};
		// add that array to a collection
		ArrayList<Integer> toAddList = new ArrayList<Integer>();
		for (int n : toAddArray)
		{
			toAddList.add(n);
		}

		// tree changed so should return true
		bst1.addAll(toAddList);

		bst1.clear();
		// this should be the items in order from bst1
		int[] resultArray = new int[0];

		// the actual elements in the bst in ascending order
		ArrayList<Integer> actualsList = bst1.toArrayList();
		int[] actualsArray = new int[actualsList.size()];
		for (int i = 0; i < actualsArray.length; i++)
		{
			actualsArray[i] = actualsList.get(i);
		}

		assertArrayEquals(resultArray, actualsArray);
	}

	// Make sure contains works on a randomly-filled BST
	@Test
	public void testContainsRandomSet ()
	{
		HashSet<Integer> randomSet = new HashSet<Integer>();
		while (randomSet.size() < RANDOM_SET_SIZE)
		{
			randomSet.add((int) (Math.random() * (RANDOM_SET_SIZE * 10)));
		}

		ArrayList<Integer> setList = new ArrayList<Integer>(randomSet);
		bst1.addAll(randomSet);

		bst1.contains(setList.get(1));
	}

	// Make sure contains works when only one item in the BST exists
	@Test
	public void testContainsOneItem ()
	{

		bst1.add(1);
		assertTrue(bst1.contains(1));
	}

	// Make sure contains doesn't find a nonexistent element
	@Test
	public void testContainsOneItemFalse ()
	{

		bst1.add(1);
		assertFalse(bst1.contains(3));
	}

	// A more "real world" contains test
	@Test
	public void testContainsMultipleItems ()
	{

		bst1.add(3);
		bst1.add(2);
		bst1.add(5);
		bst1.add(1);
		bst1.add(9);
		bst1.add(42);
		bst1.add(-8);
		bst1.add(15);

		assertTrue(bst1.contains(9));
	}

	// Same as above but for a nonexistent item
	@Test
	public void testContainsMultipleItemsFalse ()
	{

		bst1.add(3);
		bst1.add(2);
		bst1.add(5);
		bst1.add(1);
		bst1.add(9);
		bst1.add(42);
		bst1.add(-8);
		bst1.add(15);

		assertFalse(bst1.contains(10));
	}

	// Make sure contains throws an exception when told to find null
	@Test (expected = NullPointerException.class)
	public void testContainsException ()
	{

		bst1.add(3);
		bst1.add(2);
		bst1.add(5);
		bst1.add(1);
		bst1.add(9);
		bst1.add(42);
		bst1.add(-8);
		bst1.add(15);

		bst1.contains(null);
	}

	// Make sure containsAll works
	@Test
	public void testContainsAll ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		// create an array
		int[] contain = {13, 2, 5, 8};
		// add that array to a collection
		ArrayList<Integer> containList = new ArrayList<Integer>();
		for (int n : contain)
		{
			containList.add(n);
		}
		assertTrue(bst1.containsAll(containList));
	}

	// Make sure containsAll can catch a single nonexistent item among a list of
	// legitimate queries
	@Test
	public void testContainsAllWithFake ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		// create an array
		int[] contain = {13, 2, 5, 8, 10};
		// add that array to a collection
		ArrayList<Integer> containList = new ArrayList<Integer>();
		for (int n : contain)
		{
			containList.add(n);
		}
		assertFalse(bst1.containsAll(containList));
	}

	// Make sure containsAll throws a NullPointerException when expected
	@Test (expected = NullPointerException.class)
	public void testContainsAllException ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		// create an array
		int[] contain = {13, 2, 5, (Integer) null, 8, 10};
		// add that array to a collection
		ArrayList<Integer> containList = new ArrayList<Integer>();
		for (int n : contain)
		{
			containList.add(n);
		}
		assertFalse(bst1.containsAll(containList));
	}

	// Make sure first finds the proper element
	@Test
	public void testFirst ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		assertEquals(0, (int) bst1.first());
	}

	// Make sure finding the first element of an empty BST throws an exception
	@Test (expected = NoSuchElementException.class)
	public void testFirstException ()
	{
		bst1.first();
	}

	// Make sure isEmpty works on an empty BST
	@Test
	public void testIsEmpty ()
	{
		assertTrue(bst1.isEmpty());
	}

	// Make sure isEmpty recognizes a nonempty BST
	@Test
	public void testIsNotEmpty ()
	{
		bst1.add(1);
		assertFalse(bst1.isEmpty());
	}

	// Make sure last finds the proper element
	@Test
	public void testLast ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		assertEquals(42, (int) bst1.last());
	}

	// Make sure finding the last element of an empty BST throws an exception
	@Test (expected = NoSuchElementException.class)
	public void testLastException ()
	{
		bst1.last();
	}

	// Make sure remove works on the only element in the BST
	@Test
	public void testRemoveRootOneItem ()
	{
		bst1.add(23);
		assertTrue(bst1.remove(23));
	}

	// Make sure remove can properly remove the root when the root is a parent
	@Test
	public void testRemoveRootMultipleItems ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		assertTrue(bst1.remove(6));
	}

	// A more thorough repeat of the above
	@Test
	public void testRemoveRootToArrayList ()
	{
		// create a tree
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		// remove the root
		bst1.remove(6);

		// put the current state of the tree in an int array
		ArrayList<Integer> resultsList = bst1.toArrayList();
		int[] resultsArray = new int[resultsList.size()];
		for (int i = 0; i < resultsArray.length; i++)
		{
			resultsArray[i] = resultsList.get(i);
		}

		// array containing the expected result of the above array
		int[] expectedArray = {0, 1, 2, 5, 8, 12, 13, 42};

		// arrays should be equal
		assertArrayEquals(expectedArray, resultsArray);

	}

	// Make sure remove works on leaf nodes
	@Test
	public void testRemoveLeaf ()
	{
		// build tree
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		// remove 5, which is a leaf of the tree
		assertTrue(bst1.remove(5));
	}

	// Make sure remove works on leaf nodes
	@Test
	public void testRemoveLeafToArray ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		// remove a leaf
		bst1.remove(5);

		// put the current state of the tree in an int array
		ArrayList<Integer> resultsList = bst1.toArrayList();
		int[] resultsArray = new int[resultsList.size()];
		for (int i = 0; i < resultsArray.length; i++)
		{
			resultsArray[i] = resultsList.get(i);
		}

		// array containing the expected result of the above array
		int[] expectedArray = {0, 1, 2, 6, 8, 12, 13, 42};

		// arrays should be equal
		assertArrayEquals(expectedArray, resultsArray);

	}

	// Ensure that remove works on parent nodes with one child
	@Test
	public void testRemoveOneChild ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		// check the return value of remove(8) which has one child subtree
		assertTrue(bst1.remove(8));
	}

	// Ensure that remove works on parent nodes with one child
	@Test
	public void testRemoveOneChildToArrayList ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		// remove 8 which has one child
		bst1.remove(8);

		// put the current state of the tree in an int array
		ArrayList<Integer> resultsList = bst1.toArrayList();
		int[] resultsArray = new int[resultsList.size()];
		for (int i = 0; i < resultsArray.length; i++)
		{
			resultsArray[i] = resultsList.get(i);
		}

		// array containing the expected result of the above array
		int[] expectedArray = {0, 1, 2, 5, 6, 12, 13, 42};

		// arrays should be equal
		assertArrayEquals(expectedArray, resultsArray);
	}

	// Make sure remove works on nodes with two children
	@Test
	public void testRemoveTwoChildren ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		assertTrue(bst1.remove(2));
	}

	// Make sure remove works on nodes with two children
	@Test
	public void testRemoveTwoChildrenToArrayList ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		// remove 2 which has two children
		bst1.remove(2);

		// put the current state of the tree in an int array
		ArrayList<Integer> resultsList = bst1.toArrayList();
		int[] resultsArray = new int[resultsList.size()];
		for (int i = 0; i < resultsArray.length; i++)
		{
			resultsArray[i] = resultsList.get(i);
		}

		// array containing the expected result of the above array
		int[] expectedArray = {0, 1, 5, 6, 8, 12, 13, 42};

		// arrays should be equal
		assertArrayEquals(expectedArray, resultsArray);
	}

	// Make sure remove doesn't make any changes when asked to remove
	// a nonexistent element
	@Test
	public void testRemoveNonExistent ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		bst1.remove(25);
		assertFalse(bst1.remove(25));
	}

	// Make sure remove doesn't make any changes when asked to remove
	// a nonexistent element
	@Test
	public void testRemoveNonExistentToArrayList ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);

		bst1.remove(25);
		bst1.remove(25);

		// put the current state of the tree in an int array
		ArrayList<Integer> resultsList = bst1.toArrayList();
		int[] resultsArray = new int[resultsList.size()];
		for (int i = 0; i < resultsArray.length; i++)
		{
			resultsArray[i] = resultsList.get(i);
		}

		// array containing the expected result of the above array
		int[] expectedArray = {1, 2, 5, 6, 8, 12, 13, 42};

		// arrays should be equal
		assertArrayEquals(expectedArray, resultsArray);
	}

	// Make sure removeAll works
	@Test
	public void testRemoveAll ()
	{
		bst1.add(6); // will be removed
		bst1.add(2); // will be removed
		bst1.add(8);
		bst1.add(1); // will be removed
		bst1.add(5);
		bst1.add(12); // will be removed
		bst1.add(42);
		bst1.add(13);
		// create an array
		int[] toRemove = {12, 6, 33, 2, 1, 0, 9001};
		// add that array to a collection
		ArrayList<Integer> toRemoveList = new ArrayList<Integer>();
		for (int n : toRemove)
		{
			toRemoveList.add(n);
		}
		Integer[] expected = {5, 8, 13, 42};
		bst1.removeAll(toRemoveList);
		assertArrayEquals(expected, bst1.toArrayList().toArray());
	}

	// Make sure removeAll works
	@Test
	public void testRemoveAllTwice ()
	{
		bst1.add(6); // will be removed
		bst1.add(2); // will be removed
		bst1.add(8);
		bst1.add(1); // will be removed
		bst1.add(5);
		bst1.add(12); // will be removed
		bst1.add(42);
		bst1.add(13);
		// create an array
		int[] toRemove = {12, 6, 33, 2, 1, 0, 9001};
		// add that array to a collection
		ArrayList<Integer> toRemoveList = new ArrayList<Integer>();
		for (int n : toRemove)
		{
			toRemoveList.add(n);
		}
		Integer[] expected = {5, 8, 13, 42};
		bst1.removeAll(toRemoveList);
		bst1.removeAll(toRemoveList);
		assertArrayEquals(expected, bst1.toArrayList().toArray());
	}

	// Make sure removeAll works
	@Test
	public void testRemoveAllReturnValueTrue ()
	{
		bst1.add(6); // will be removed
		bst1.add(2); // will be removed
		bst1.add(8);
		bst1.add(1); // will be removed
		bst1.add(5);
		bst1.add(12); // will be removed
		bst1.add(42);
		bst1.add(13);

		// create an array
		int[] toRemove = {12, 6, 33, 2, 1, 0, 9001};
		// add that array to a collection
		ArrayList<Integer> toRemoveList = new ArrayList<Integer>();
		for (int n : toRemove)
		{
			toRemoveList.add(n);
		}
		Integer[] expected = {5, 8, 13, 42};
		assertTrue(bst1.removeAll(toRemoveList));
	}

	// Make sure removeAll works
	@Test
	public void testRemoveAllReturnValueFalse ()
	{
		bst1.add(6); // will be removed
		bst1.add(2); // will be removed
		bst1.add(8);
		bst1.add(1); // will be removed
		bst1.add(5);
		bst1.add(12); // will be removed
		bst1.add(42);
		bst1.add(13);

		// create an array
		int[] toRemove = {12, 6, 33, 2, 1, 0, 9001};
		// add that array to a collection
		ArrayList<Integer> toRemoveList = new ArrayList<Integer>();
		for (int n : toRemove)
		{
			toRemoveList.add(n);
		}
		Integer[] expected = {5, 8, 13, 42};
		bst1.removeAll(toRemoveList);

		assertFalse(bst1.removeAll(toRemoveList));
	}

	// Make sure size works and add/remove increment/decrement the size properly
	@Test
	public void testSize ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.remove(6);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		assertEquals(7, bst1.size());
	}

	// Make sure the size of a newly created BST is 0
	@Test
	public void testSizeEmpty ()
	{
		assertEquals(0, bst1.size());
	}

	// Make sure toArrayList outputs an array that matches expectations
	@Test
	public void testToArrayList ()
	{
		bst1.add(6);
		bst1.add(2);
		bst1.add(8);
		bst1.add(1);
		bst1.add(0);
		bst1.add(5);
		bst1.add(12);
		bst1.add(42);
		bst1.add(13);
		Integer[] compare = {0, 1, 2, 5, 6, 8, 12, 13, 42};
		assertArrayEquals((Object[]) compare, bst1.toArrayList().toArray());

	}

	// Make sure toArrayList generates an empty list for an empty BST
	@Test
	public void testToEmptyArrayList ()
	{
		Integer[] compare = {};
		assertArrayEquals((Object[]) compare, bst1.toArrayList().toArray());
	}

}
